export interface Application {
  postId: string;
  from: string;
  to: string;
  status: string;
}
