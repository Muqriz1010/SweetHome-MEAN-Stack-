export interface Post {
  id: string;
  residencename: string;
  state: string;
  address: string;
  size: string;
  price: string;
  imagePath: string;
}
