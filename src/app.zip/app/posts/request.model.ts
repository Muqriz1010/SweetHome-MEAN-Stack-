export interface Request {
  id: string;
  applicantname: string;
  residencename: String;
  imagePath: string;
  from: string;
  to: string;
  status: string;
}
