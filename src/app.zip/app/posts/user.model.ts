export interface User {
  applicantname: String;
}
